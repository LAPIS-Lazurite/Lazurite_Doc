#ifndef _AAA_H_
#define _AAA_H_

extern void led_init(unsigned char pin);
extern void led(bool on);

#endif //	_AAA_H_

