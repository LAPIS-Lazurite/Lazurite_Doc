#include "lazurite.h"

static unsigned char led_pin;
void led_init(unsigned char pin)
{
	led_pin = pin;
	pinMode(led_pin,OUTPUT);
}

void led(bool on)
{
	if(on==true) {
		digitalWrite(led_pin,LOW);
	} else {
		digitalWrite(led_pin,HIGH);
	}
}

